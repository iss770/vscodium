# SSH Client For Visual Studio Code

![preview](https://github.com/cweijan/vscode-ssh/raw/master/preview.jpg)

## Feature

- Save ssh config.
- Convenient to connect to ssh in terminal.
- Convenient opearation sftp.

## Usage
1. Open SSH view.
2. Click add button.
